"use client";

import { useState } from "react";

export default function AdminUploadPage() {
  const [password, setPassword] = useState("");
  const [statsDate, setStatsDate] = useState("");
  const [dailyFile, setDailyFile] = useState<File | null>(null);
  const [lifetimeFile, setLifetimeFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus(null);

    if (!password) return setStatus("❌ Enter admin password.");
    if (!statsDate) return setStatus("❌ Pick a stats date.");
    if (!dailyFile) return setStatus("❌ Choose a DAILY .xlsx file.");
    if (!lifetimeFile) return setStatus("❌ Choose a LIFETIME .xlsx file.");

    const form = new FormData();
    form.append("statsDate", statsDate);
    form.append("dailyFile", dailyFile);
    form.append("lifetimeFile", lifetimeFile);

    setLoading(true);

    try {
      const res = await fetch("/admin/upload", {
        method: "POST",
        headers: {
          "x-admin-password": password,
        },
        body: form,
      });

      const json = await res.json().catch(() => ({}));

      if (!res.ok) {
        setStatus(`❌ ${json.error || "Upload failed"}`);
      } else {
        setStatus(`✅ ${json.message || "Upload complete!"}`);
      }
    } catch (err: any) {
      setStatus(`❌ Error: ${err.message}`);
    }

    setLoading(false);
  }

  return (
    <main
      style={{
        padding: "40px",
        maxWidth: "600px",
        margin: "0 auto",
        fontFamily: "sans-serif",
      }}
    >
      <h1 style={{ fontSize: "32px", marginBottom: "20px" }}>
        Admin · Upload Stats
      </h1>

      <p style={{ marginBottom: "20px", opacity: 0.8 }}>
        Upload your <strong>Daily</strong> and <strong>Lifetime</strong> Excel
        sheets from TikTok.  
        This will update all creators and their calendars.
      </p>

      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "18px",
        }}
      >
        <div>
          <label style={{ fontWeight: 600 }}>Admin Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "6px",
              border: "1px solid #ccc",
              marginTop: "6px",
            }}
          />
        </div>

        <div>
          <label style={{ fontWeight: 600 }}>Stats Date</label>
          <input
            type="date"
            value={statsDate}
            onChange={(e) => setStatsDate(e.target.value)}
            required
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "6px",
              border: "1px solid #ccc",
              marginTop: "6px",
            }}
          />
        </div>

        <div>
          <label style={{ fontWeight: 600 }}>
            Daily File (username, diamonds, hours)
          </label>
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setDailyFile(e.target.files?.[0] ?? null)}
            required
            style={{ marginTop: "6px" }}
          />
        </div>

        <div>
          <label style={{ fontWeight: 600 }}>
            Lifetime File (username, lifetime diamonds, lifetime hours)
          </label>
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setLifetimeFile(e.target.files?.[0] ?? null)}
            required
            style={{ marginTop: "6px" }}
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          style={{
            padding: "12px",
            background: loading ? "#888" : "#0070f3",
            color: "#fff",
            border: "none",
            borderRadius: "6px",
            cursor: loading ? "not-allowed" : "pointer",
            fontSize: "16px",
            fontWeight: 600,
            marginTop: "10px",
          }}
        >
          {loading ? "Uploading…" : "Upload Stats"}
        </button>

        {status && (
          <p
            style={{
              padding: "12px",
              borderRadius: "6px",
              marginTop: "10px",
              background: status.startsWith("✅")
                ? "#d1f7d1"
                : "#ffd6d6",
              color: status.startsWith("✅") ? "#0a630a" : "#8a0b0b",
              fontWeight: 600,
            }}
          >
            {status}
          </p>
        )}
      </form>
    </main>
  );
}
