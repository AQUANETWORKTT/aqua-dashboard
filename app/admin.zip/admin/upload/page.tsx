"use client";

import { useState } from "react";

export default function AdminUploadPage() {
  const [password, setPassword] = useState("");
  const [statsDate, setStatsDate] = useState("");
  const [dailyFile, setDailyFile] = useState<File | null>(null);
  const [lifetimeFile, setLifetimeFile] = useState<File | null>(null);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    setStatus("");

    if (!statsDate || !dailyFile || !lifetimeFile) {
      setStatus("❌ Missing fields");
      return;
    }

    setLoading(true);

    const form = new FormData();
    form.append("statsDate", statsDate);
    form.append("dailyFile", dailyFile);
    form.append("lifetimeFile", lifetimeFile);

    try {
      const res = await fetch("/admin/upload", {
        method: "POST",
        headers: {
          "x-admin-password": password,
        },
        body: form,
      });

      const json = await res.json();

      if (!res.ok) {
        setStatus(`❌ Error: ${json.error}`);
      } else {
        setStatus(`✅ ${json.message}`);
      }
    } catch (e) {
      setStatus("❌ Failed to upload files");
    }

    setLoading(false);
  }

  return (
    <main style={{ padding: 20 }}>
      <h1>Admin Upload</h1>

      <form onSubmit={handleUpload}>
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <br /><br />

        <label>Stats Date:</label>
        <input
          type="date"
          value={statsDate}
          onChange={(e) => setStatsDate(e.target.value)}
          required
        />

        <br /><br />

        <label>Daily XLSX:</label>
        <input
          type="file"
          accept=".xlsx"
          onChange={(e) => setDailyFile(e.target.files?.[0] ?? null)}
          required
        />

        <br /><br />

        <label>Lifetime XLSX:</label>
        <input
          type="file"
          accept=".xlsx"
          onChange={(e) => setLifetimeFile(e.target.files?.[0] ?? null)}
          required
        />

        <br /><br />

        <button type="submit" disabled={loading}>
          {loading ? "Uploading..." : "Upload Stats"}
        </button>

        {status && (
          <p style={{ marginTop: 20 }}>
            {status}
          </p>
        )}
      </form>
    </main>
  );
}
